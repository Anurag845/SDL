import java.util.*;

public class Global {
	static int count = 0;
	static Set<Bus> buses = new HashSet<Bus>();
	static HashMap<Integer,Customer> passtick = new HashMap<>();
	static ArrayList<Person> person = new ArrayList<Person>();
}