
public class Person {
	
	String username;
	String password;
	String name;
	long aadhar;
	String designation;
	int id;
	String emailid;
	
	public Person(String username, String password, String name, long aadhar, String designation, int id,String emailid) {
		this.username = username;
		this.password = password;
		this.name = name;
		this.aadhar = aadhar;
		this.designation = designation;
		this.id = id;
		this.emailid = emailid;
	}
}
