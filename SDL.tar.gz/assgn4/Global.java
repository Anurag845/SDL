import java.util.*;

public class Global {
	static Set<Bus> buses = new HashSet<Bus>();
	static HashMap<Integer,Customer> passtick = new HashMap<>();
}